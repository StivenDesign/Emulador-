package com.nova.emulator.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nova.emulator.core.*
import java.text.DateFormat
import java.util.Date

enum class Tab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Home("Inicio", Icons.Default.Dashboard),
    Apps("Apps", Icons.Default.Apps),
    Envs("Entornos", Icons.Default.Memory),
    Log("Registro", Icons.Default.Terminal),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaRoot(vm: NovaViewModel) {
    var tab by remember { mutableStateOf(Tab.Home) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    val pending by vm.pendingInstall.collectAsStateWithLifecycle()
    pending?.let { p ->
        AlertDialog(
            onDismissRequest = vm::cancelInstall,
            title = { Text("¿Ejecutar este instalador?") },
            text = {
                Text("${java.io.File(p.installerPath).name}\n\nLos programas de Windows pueden contener malware. " +
                    "Se ejecutará dentro del entorno aislado, pero solo continúa si confías en el archivo.")
            },
            confirmButton = { TextButton(onClick = vm::confirmInstall) { Text("Ejecutar") } },
            dismissButton = { TextButton(onClick = vm::cancelInstall) { Text("Cancelar") } },
        )
    }

    Scaffold(
        containerColor = NovaBg,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0E1020)) {
                Tab.values().forEach {
                    NavigationBarItem(selected = tab == it, onClick = { tab = it },
                        icon = { Icon(it.icon, null) }, label = { Text(it.title) })
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            Crossfade(tab, animationSpec = tween(250), label = "tab") {
                when (it) {
                    Tab.Home -> HomeScreen(vm)
                    Tab.Apps -> AppsScreen(vm)
                    Tab.Envs -> EnvsScreen(vm)
                    Tab.Log -> LogScreen(vm)
                }
            }
        }
    }
}

@Composable
private fun Appear(index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(index * 70L); shown = true }
    AnimatedVisibility(shown, enter = fadeIn(tween(350)) + slideInVertically(tween(350)) { it / 5 }) { content() }
}

@Composable
private fun Title(text: String) = Text(text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))

// ───────────────────────── INICIO ─────────────────────────
@Composable
fun HomeScreen(vm: NovaViewModel) {
    val engines by vm.engines.collectAsStateWithLifecycle()
    val containers by vm.containers.collectAsStateWithLifecycle()
    val running by vm.running.collectAsStateWithLifecycle()
    val selected = vm.selectedContainer(containers)
    val ready = engines.firstOrNull { it.ready }

    val pickEngine = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importEngine) }
    val pickInstaller = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selected != null) vm.importInstaller(selected.id, uri)
    }
    var newEnv by remember { mutableStateOf(false) }
    if (newEnv) NewEnvDialog(engines, onDismiss = { newEnv = false }) { n, e -> vm.createContainer(n, e); newEnv = false }

    val recent = containers.flatMap { c -> c.apps.map { c to it } }.filter { it.second.lastRunAt != null }
        .sortedByDescending { it.second.lastRunAt }.take(5)

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("NOVA", fontSize = 34.sp, fontWeight = FontWeight.Black, color = NovaPurple)
            Text("EMULATOR", fontSize = 14.sp, letterSpacing = 6.sp, color = NovaCyan)
        }
        item { Appear(0) { EngineCard(ready, engines.size) { pickEngine.launch(arrayOf("application/zip", "application/octet-stream")) } } }
        item {
            Appear(1) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Stat("Entornos", containers.size.toString(), Modifier.weight(1f))
                    Stat("Apps", containers.sumOf { it.apps.size }.toString(), Modifier.weight(1f))
                    Stat("En ejecución", running.size.toString(), Modifier.weight(1f))
                }
            }
        }
        item {
            Appear(2) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionButton("Crear entorno", Icons.Default.AddBox) { newEnv = true }
                    ActionButton(
                        "Importar instalador EXE / MSI" + (selected?.let { " → ${it.name}" } ?: ""),
                        Icons.Default.UploadFile,
                    ) {
                        if (selected == null) vm.messages.tryEmit("Crea un entorno primero")
                        else pickInstaller.launch(arrayOf("*/*"))
                    }
                }
            }
        }
        item { Title("Últimas ejecutadas") }
        if (recent.isEmpty()) item { Text("Aún no has ejecutado ninguna aplicación.", color = Color.Gray) }
        items(recent) { (c, a) ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.SemiBold)
                        Text("${c.name} · " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(a.lastRunAt!!)),
                            fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
private fun EngineCard(engine: Engine?, total: Int, onImport: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse").animateFloat(
        0.4f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "a")
    GlassCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).alpha(if (engine != null) pulse.value else 1f).clip(CircleShape)
                    .background(if (engine != null) NovaOk else NovaWarn))
                Spacer(Modifier.width(8.dp))
                Text("Motor de emulación", fontWeight = FontWeight.Bold)
            }
            if (engine == null) {
                Text(if (total == 0) "No instalado. Importa un paquete de motor (.zip con nova-engine.json) para poder ejecutar programas."
                else "Hay motores importados pero ninguno es utilizable.", color = Color.LightGray, fontSize = 13.sp)
            } else {
                val m = engine.manifest
                Text("${m.name} ${m.version} · Wine ${m.wineVersion}", fontSize = 13.sp)
                Text(listOfNotNull(m.dxvkVersion?.let { "DXVK $it" }, m.vkd3dVersion?.let { "VKD3D $it" }, m.turnipVersion?.let { "Turnip $it" })
                    .joinToString(" · ").ifEmpty { "Sin capas gráficas declaradas" }, fontSize = 12.sp, color = Color.Gray)
            }
            OutlinedButton(onClick = onImport, shape = RoundedCornerShape(14.dp)) { Text("Importar motor (.zip)") }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) = GlassCard(modifier) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = NovaCyan)
        Text(label, fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
private fun ActionButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.97f else 1f, label = "press")
    Button(onClick = onClick, interactionSource = src, shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().scale(s), contentPadding = PaddingValues(16.dp)) {
        Icon(icon, null); Spacer(Modifier.width(10.dp)); Text(text)
    }
}

@Composable
private fun NewEnvDialog(engines: List<Engine>, onDismiss: () -> Unit, onCreate: (String, String?) -> Unit) {
    var name by remember { mutableStateOf("") }
    var engineId by remember { mutableStateOf(engines.firstOrNull { it.ready }?.id ?: engines.firstOrNull()?.id) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo entorno") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true)
                if (engines.isEmpty()) Text("Sin motores: el entorno se creará pero no podrá ejecutar nada hasta importar uno.", fontSize = 12.sp, color = NovaWarn)
                engines.forEach { e ->
                    Row(Modifier.fillMaxWidth().clickable { engineId = e.id }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(engineId == e.id, { engineId = e.id })
                        Text("${e.manifest.name} ${e.manifest.version}" + (e.problem?.let { " ⚠ $it" } ?: ""), fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onCreate(name, engineId) }) { Text("Crear") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ───────────────────────── APPS ─────────────────────────
@Composable
fun AppsScreen(vm: NovaViewModel) {
    val containers by vm.containers.collectAsStateWithLifecycle()
    val running by vm.running.collectAsStateWithLifecycle()
    val scan by vm.scanResults.collectAsStateWithLifecycle()
    val c = vm.selectedContainer(containers)

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Title("Aplicaciones") }
        if (c == null) {
            item { Text("Crea un entorno en Inicio para empezar.", color = Color.Gray) }
            return@LazyColumn
        }
        item { Text("Entorno: ${c.name}", color = NovaCyan) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.scan(c.id) }) { Text("Buscar .exe") }
                OutlinedButton(onClick = { vm.openUninstaller(c.id) }) { Text("Desinstalar…") }
            }
        }
        if (scan.isNotEmpty()) {
            item { Text("Ejecutables encontrados (toca para registrar)", fontSize = 12.sp, color = Color.Gray) }
            items(scan) { f ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(f.name, Modifier.weight(1f), fontSize = 13.sp)
                        TextButton(onClick = { vm.register(c.id, f, false) }) { Text("App") }
                        TextButton(onClick = { vm.register(c.id, f, true) }) { Text("Juego") }
                    }
                }
            }
        }
        if (c.apps.isEmpty()) item { Text("No hay aplicaciones registradas. Instala una o busca .exe en el prefijo.", color = Color.Gray) }
        items(c.apps, key = { it.id }) { a ->
            val session = running.values.firstOrNull { it.containerId == c.id && it.label == a.name }
            GlassCard(Modifier.fillMaxWidth().animateItem()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (a.isGame) Icons.Default.SportsEsports else Icons.Default.Window, null, tint = NovaPurple)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontWeight = FontWeight.SemiBold)
                        Text(if (session != null) "En ejecución" else if (a.isGame) "Juego" else "Aplicación", fontSize = 12.sp,
                            color = if (session != null) NovaOk else Color.Gray)
                    }
                    if (session != null) IconButton({ vm.stop(session.id) }) { Icon(Icons.Default.Stop, "Detener", tint = NovaErr) }
                    else IconButton({ vm.runApp(c.id, a) }) { Icon(Icons.Default.PlayArrow, "Ejecutar", tint = NovaOk) }
                    IconButton({ vm.removeApp(c.id, a.id) }) { Icon(Icons.Default.Delete, "Quitar del listado") }
                }
            }
        }
    }
}

// ───────────────────────── ENTORNOS ─────────────────────────
@Composable
fun EnvsScreen(vm: NovaViewModel) {
    val containers by vm.containers.collectAsStateWithLifecycle()
    val engines by vm.engines.collectAsStateWithLifecycle()
    val selected = vm.selectedContainer(containers)
    var editing by remember { mutableStateOf<ContainerConfig?>(null) }
    editing?.let { cfg -> EditEnvDialog(cfg, onDismiss = { editing = null }) { new -> vm.updateContainer(cfg.id) { new }; editing = null } }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Title("Entornos") }
        if (containers.isEmpty()) item { Text("No hay entornos.", color = Color.Gray) }
        items(containers, key = { it.id }) { c ->
            val engine = engines.firstOrNull { it.id == c.engineId }
            GlassCard(Modifier.fillMaxWidth().animateItem()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected?.id == c.id, { vm.selectedId.value = c.id })
                        Text(c.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconButton({ editing = c }) { Icon(Icons.Default.Settings, "Configurar") }
                        IconButton({ vm.deleteContainer(c.id) }) { Icon(Icons.Default.Delete, "Eliminar") }
                    }
                    Text("Motor: " + (engine?.let { "${it.manifest.name} ${it.manifest.version}" + (it.problem?.let { p -> " ⚠ $p" } ?: "") } ?: "ninguno"),
                        fontSize = 12.sp, color = Color.Gray)
                    Text("${c.resolution} · ${c.dxWrapper} · ${c.apps.size} apps", fontSize = 12.sp, color = Color.Gray)
                    OutlinedButton(onClick = { vm.initPrefix(c.id) }, shape = RoundedCornerShape(12.dp)) { Text("Inicializar prefijo de Wine") }
                }
            }
        }
        if (engines.isNotEmpty()) {
            item { Title("Motores importados") }
            items(engines, key = { it.id }) { e ->
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${e.manifest.name} ${e.manifest.version}", fontWeight = FontWeight.SemiBold)
                            Text(e.problem ?: "Listo", fontSize = 12.sp, color = if (e.ready) NovaOk else NovaWarn)
                        }
                        IconButton({ vm.deleteEngine(e.id) }) { Icon(Icons.Default.Delete, "Eliminar motor") }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditEnvDialog(c: ContainerConfig, onDismiss: () -> Unit, onSave: (ContainerConfig) -> Unit) {
    var res by remember { mutableStateOf(c.resolution) }
    var mem by remember { mutableStateOf(c.memoryLimitMb.toString()) }
    var dx by remember { mutableStateOf(c.dxWrapper) }
    var env by remember { mutableStateOf(c.env.entries.joinToString("\n") { "${it.key}=${it.value}" }) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configurar ${c.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(res, { res = it }, label = { Text("Resolución (ej. 1280x720)") }, singleLine = true)
                OutlinedTextField(mem, { mem = it.filter(Char::isDigit) }, label = { Text("Memoria MB (informativo)") }, singleLine = true)
                Row { listOf("dxvk", "vkd3d", "wined3d").forEach { o ->
                    FilterChip(dx == o, { dx = o }, label = { Text(o) }, modifier = Modifier.padding(end = 6.dp)) } }
                OutlinedTextField(env, { env = it }, label = { Text("Variables (CLAVE=valor por línea)") }, minLines = 3)
                Text("La resolución y el wrapper gráfico se guardan; se aplicarán cuando exista la capa de pantalla (Fase 7).",
                    fontSize = 11.sp, color = Color.Gray)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val parsed = env.lines().mapNotNull { l -> l.split("=", limit = 2).takeIf { it.size == 2 && it[0].isNotBlank() }?.let { it[0].trim() to it[1].trim() } }.toMap()
                val valid = Regex("\\d{3,5}x\\d{3,5}").matches(res)
                onSave(c.copy(resolution = if (valid) res else c.resolution, memoryLimitMb = mem.toIntOrNull() ?: c.memoryLimitMb, dxWrapper = dx, env = parsed))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ───────────────────────── REGISTRO ─────────────────────────
@Composable
fun LogScreen(vm: NovaViewModel) {
    val logs by vm.logs.collectAsStateWithLifecycle()
    val running by vm.running.collectAsStateWithLifecycle()
    val state = rememberLazyListState()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) state.animateScrollToItem(logs.size - 1) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Title("Registro")
            Spacer(Modifier.weight(1f))
            TextButton(onClick = vm::clearLogs) { Text("Limpiar") }
        }
        running.values.forEach { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("● ${s.label}", color = NovaOk, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton({ vm.stop(s.id) }) { Text("Detener") }
            }
        }
        if (logs.isEmpty()) Text("Sin salida todavía. Aquí se muestra la salida real de Wine/Box64 y los errores del sistema.", color = Color.Gray)
        LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            items(logs) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp,
                color = if (it.contains("err", true) || it.contains("ERROR")) NovaErr else Color(0xFFD1D5DB)) }
        }
    }
}
