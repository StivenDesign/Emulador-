# NOVA EMULATOR — Fase 1: Viabilidad técnica

## Veredicto

Viable, con condiciones. Una app Android que ejecuta software de Windows existe y funciona
(Winlator, GameNative, entre otros). Lo que NO es viable es escribir ese núcleo desde cero en
una sola sesión: un servidor X11/Wayland, un conjunto de binarios de Wine y Box64 compilados para
Android y el puente gráfico son años de trabajo. La ruta realista es:

1. App propia (Kotlin + Compose) con gestor de entornos, instalador y UI.
2. Motor = paquetes binarios reales (Wine, Box64, DXVK, VKD3D-Proton, Turnip) que la app importa
   y gestiona, no que simula.
3. Capa nativa (NDK/JNI) para lanzar procesos, montar el rootfs y exponer el estado real.
4. Servidor X11 y presentación gráfica: se reutiliza el enfoque de código abierto de Winlator
   (XServer en Java/C + Vulkan/OpenGL) en lugar de reinventarlo.

## Compatibilidad de motores en Android ARM64

| Tecnología | Papel | Viable en Android | Notas |
|---|---|---|---|
| Wine (build ARM64 + x86_64) | API de Windows | Sí | Corre x86_64 vía Box64; Wine ARM64 nativo solo para apps ARM |
| Box64 | Traducción x86_64 → ARM64 (dynarec) | Sí | Núcleo del rendimiento |
| Box86 | x86 32 bits | Parcial | Requiere libs 32 bits en ARM64; muchos SoC recientes han quitado el modo 32 bits, Box86 corre en 64 bits con wine-wow64 en builds modernos |
| DXVK | D3D9/10/11 → Vulkan | Sí | Requiere Vulkan 1.1+ con extensiones; depende del driver |
| VKD3D-Proton | D3D12 → Vulkan | Parcial | Exige características Vulkan que muchos drivers móviles no tienen; solo en GPUs capaces |
| Turnip (Mesa) | Driver Vulkan | Solo Adreno | Se carga como driver alterno; Mali/PowerVR no lo usan |
| FEX-Emu | Alternativa a Box64 | Experimental | Más precisa, normalmente menos rápida en Android; opcional |
| Contenedores Linux | Aislamiento | Parcial | Sin root: proot o chroot propio del rootfs; sin namespaces reales |

Combinaciones recomendadas:
- Adreno: Wine + Box64 + DXVK (+ VKD3D-Proton opcional) + Turnip.
- Mali / PowerVR: Wine + Box64 + DXVK sobre driver del fabricante (compatibilidad menor) o
  renderizado OpenGL vía Zink/WineD3D (lento).

## Restricciones críticas de Android

1. **W^X / ejecución desde el almacenamiento de la app**: desde Android 10, apps con
   `targetSdk >= 29` no pueden ejecutar binarios escritos en su directorio de datos. Winlator
   evita esto con `targetSdk 28`. Consecuencia: no se podrá publicar en Google Play con ese
   target; la distribución sería por APK directo. Alternativa: empaquetar los ejecutables como
   librerías en `jniLibs` (se extraen en `nativeLibraryDir`, ejecutables), con límites.
2. **Memoria**: Android mata procesos en segundo plano; se necesita servicio en primer plano.
3. **Rendimiento**: la traducción de CPU y el estrangulamiento térmico limitan los juegos pesados.
4. **Anti-cheat y DRM** (EAC, BattlEye, Denuvo, etc.): normalmente no funcionan.
5. **Instaladores MSI y .NET**: requieren winetricks/dependencias (vcrun, dotnet, DirectX
   redistributable) instalables dentro del prefijo.

## Licencias (verificar la versión exacta antes de distribuir)

| Componente | Licencia habitual |
|---|---|
| Wine | LGPL 2.1+ |
| Box64 / Box86 | MIT |
| DXVK | zlib/libpng |
| VKD3D-Proton | LGPL 2.1+ |
| Mesa / Turnip | MIT |
| FEX-Emu | MIT |
| Winlator | MIT (confirmar en el repo original) |

Obligaciones: conservar avisos, ofrecer fuente de componentes LGPL y no mezclar binarios sin
documentar sus orígenes. Esta tabla viene de conocimiento previo y debe confirmarse en cada repo.

## Qué es real en esta entrega y qué no

Real:
- Gestor de entornos (contenedores) con configuración persistente.
- Importación de paquetes de motor desde almacenamiento (el usuario aporta los binarios).
- Lanzamiento y control de procesos con registro de salida real.
- UI Compose con todas las pantallas conectadas a esa lógica.

No incluido (y la app lo muestra como tal):
- Binarios de Wine/Box64/DXVK: no se pueden descargar desde este entorno y no se incluyen.
  Mientras no haya un motor importado, la app indica "motor no instalado" y bloquea la ejecución.
- Servidor X11 y salida gráfica: pendiente (Fase 5/7). Sin él no hay ventana de aplicación.
- FPS: solo se mostrarán cuando una capa gráfica real los reporte.
