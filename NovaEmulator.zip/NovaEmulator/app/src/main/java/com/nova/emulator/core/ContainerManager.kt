package com.nova.emulator.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/** Entornos aislados: cada uno tiene su propio prefijo de Wine y su config.json. */
class ContainerManager(context: Context) {
    private val ctx = context.applicationContext
    private val root = File(ctx.filesDir, "containers").apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private val _containers = MutableStateFlow<List<ContainerConfig>>(emptyList())
    val containers: StateFlow<List<ContainerConfig>> = _containers

    init { reload() }

    fun dir(id: String) = File(root, id)
    fun prefixDir(id: String) = File(dir(id), "prefix")
    fun installersDir(id: String) = File(prefixDir(id), "drive_c/nova_installers")
    fun get(id: String?) = _containers.value.firstOrNull { it.id == id }

    private fun reload() {
        _containers.value = root.listFiles { f -> f.isDirectory }.orEmpty().mapNotNull {
            runCatching { json.decodeFromString<ContainerConfig>(File(it, "config.json").readText()) }.getOrNull()
        }.sortedBy { it.name.lowercase() }
    }

    fun create(name: String, engineId: String?): ContainerConfig {
        val c = ContainerConfig(id = UUID.randomUUID().toString().take(8), name = name.trim(), engineId = engineId)
        prefixDir(c.id).mkdirs()
        save(c)
        return c
    }

    fun update(id: String, f: (ContainerConfig) -> ContainerConfig) {
        get(id)?.let { save(f(it)) }
    }

    private fun save(c: ContainerConfig) {
        File(dir(c.id), "config.json").writeText(json.encodeToString(c))
        reload()
    }

    fun delete(id: String) {
        dir(id).deleteRecursively()
        reload()
    }

    /** Copia el instalador elegido por el usuario al entorno. NO lo ejecuta. */
    suspend fun importInstaller(id: String, uri: Uri): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val name = displayName(uri) ?: "installer.bin"
            val safe = File(name).name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
            val out = File(installersDir(id).apply { mkdirs() }, safe)
            val input = ctx.contentResolver.openInputStream(uri) ?: error("No se pudo abrir el archivo")
            input.use { i -> out.outputStream().use { i.copyTo(it) } }
            out
        }
    }

    /** Lista .exe del prefijo (excluye la carpeta de Windows) para registrarlos como apps. */
    fun scanExecutables(id: String): List<File> {
        val c = File(prefixDir(id), "drive_c")
        if (!c.isDirectory) return emptyList()
        return c.walkTopDown()
            .onEnter { !it.relativeTo(c).path.lowercase().startsWith("windows") && it.name != "nova_installers" }
            .filter { it.isFile && it.extension.equals("exe", true) }
            .take(300).toList()
    }

    fun addApp(id: String, app: InstalledApp) = update(id) { c ->
        if (c.apps.any { it.exePath == app.exePath }) c else c.copy(apps = c.apps + app)
    }

    fun removeApp(id: String, appId: String) = update(id) { c -> c.copy(apps = c.apps.filter { it.id != appId }) }

    fun touchApp(id: String, appId: String) = update(id) { c ->
        c.copy(apps = c.apps.map { if (it.id == appId) it.copy(lastRunAt = System.currentTimeMillis()) else it })
    }

    private fun displayName(uri: Uri): String? =
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
}
