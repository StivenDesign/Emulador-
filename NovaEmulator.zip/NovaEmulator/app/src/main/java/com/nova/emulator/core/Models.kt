package com.nova.emulator.core

import kotlinx.serialization.Serializable

/** Manifiesto (nova-engine.json) que describe un paquete de motor importado por el usuario. */
@Serializable
data class EngineManifest(
    val name: String,
    val version: String,
    val wineVersion: String,
    /** Ruta relativa al binario box64 (ARM64) dentro del paquete. */
    val box64Path: String,
    /** Ruta relativa al binario wine (x86_64) dentro del paquete. */
    val winePath: String,
    /** Directorios relativos añadidos a LD_LIBRARY_PATH. */
    val libraryPaths: List<String> = emptyList(),
    val dxvkVersion: String? = null,
    val vkd3dVersion: String? = null,
    val turnipVersion: String? = null,
    val arch: String = "arm64-v8a",
)

/** Motor instalado. [problem] es null solo si los binarios existen y son ejecutables. */
data class Engine(val id: String, val manifest: EngineManifest, val problem: String?) {
    val ready get() = problem == null
}

@Serializable
data class InstalledApp(
    val id: String,
    val name: String,
    /** Ruta absoluta del .exe dentro del prefijo del entorno. */
    val exePath: String,
    val isGame: Boolean = false,
    val lastRunAt: Long? = null,
)

@Serializable
data class ContainerConfig(
    val id: String,
    val name: String,
    val engineId: String? = null,
    val resolution: String = "1280x720",
    /** Informativo: Android no permite a una app limitar la memoria de un hijo (sin cgroups). */
    val memoryLimitMb: Int = 2048,
    /** "dxvk" | "vkd3d" | "wined3d" (se guarda; se aplica cuando exista la capa gráfica). */
    val dxWrapper: String = "dxvk",
    val env: Map<String, String> = emptyMap(),
    val apps: List<InstalledApp> = emptyList(),
)

data class Session(val id: String, val containerId: String, val label: String, val startedAt: Long)

data class PendingInstall(val containerId: String, val installerPath: String, val isMsi: Boolean)
