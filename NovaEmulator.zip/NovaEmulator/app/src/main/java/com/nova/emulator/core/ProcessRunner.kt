package com.nova.emulator.core

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * Lanza procesos reales (box64 wine ...) dentro de un entorno. No simula nada: la salida mostrada
 * es la stdout/stderr del proceso y los errores del sistema (p. ej. "Permission denied") se
 * registran tal cual.
 */
class ProcessRunner(
    context: Context,
    private val engines: EngineManager,
    private val containers: ContainerManager,
) {
    private val ctx = context.applicationContext
    private val procs = ConcurrentHashMap<String, Process>()

    private val _running = MutableStateFlow<Map<String, Session>>(emptyMap())
    val running: StateFlow<Map<String, Session>> = _running

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    fun clearLogs() { _logs.value = emptyList() }

    private fun log(line: String) {
        _logs.value = (_logs.value + line).takeLast(3000)
    }

    /** Devuelve el id de sesión, o un error legible si no se puede lanzar. */
    fun launch(containerId: String, label: String, wineArgs: List<String>): Result<String> = runCatching {
        val c = containers.get(containerId) ?: error("Entorno no encontrado")
        val engine = engines.find(c.engineId) ?: error("El entorno no tiene un motor asignado")
        engine.problem?.let { error("Motor no utilizable: $it") }
        val eDir = engines.dirOf(engine.id)
        val m = engine.manifest

        val cmd = listOf(File(eDir, m.box64Path).path, File(eDir, m.winePath).path) + wineArgs
        val pb = ProcessBuilder(cmd).directory(containers.prefixDir(c.id)).redirectErrorStream(true)
        pb.environment().apply {
            put("WINEPREFIX", containers.prefixDir(c.id).path)
            put("WINEARCH", "win64")
            put("WINEDEBUG", "err+all")      // los errores de Wine no se ocultan
            put("BOX64_LOG", "1")
            put("HOME", containers.dir(c.id).path)
            put("TMPDIR", ctx.cacheDir.path)
            put("LD_LIBRARY_PATH", m.libraryPaths.joinToString(":") { File(eDir, it).path })
            putAll(c.env)
        }

        val id = UUID.randomUUID().toString().take(6)
        log("[$label] $ ${cmd.joinToString(" ")}")
        val p = try { pb.start() } catch (e: Exception) {
            log("[$label] ERROR al iniciar: ${e.message}")
            throw e
        }
        procs[id] = p
        _running.value = _running.value + (id to Session(id, c.id, label, System.currentTimeMillis()))

        thread(name = "nova-$id", isDaemon = true) {
            p.inputStream.bufferedReader().useLines { it.forEach { l -> log("[$label] $l") } }
            val code = p.waitFor()
            log("[$label] terminó con código $code")
            procs.remove(id)
            _running.value = _running.value - id
        }
        id
    }

    fun stop(sessionId: String) {
        procs[sessionId]?.let { p ->
            p.destroy()
            thread(isDaemon = true) { Thread.sleep(3000); if (p.isAlive) p.destroyForcibly() }
        }
    }

    // --- Comandos de alto nivel ---
    fun initPrefix(containerId: String) = launch(containerId, "wineboot", listOf("wineboot", "-u"))

    fun runInstaller(p: PendingInstall): Result<String> {
        val label = File(p.installerPath).name
        val args = if (p.isMsi) listOf("msiexec", "/i", "Z:" + p.installerPath.replace('/', '\\'))
        else listOf(p.installerPath)
        return launch(p.containerId, label, args)
    }

    fun runApp(containerId: String, app: InstalledApp): Result<String> =
        launch(containerId, app.name, listOf(app.exePath)).onSuccess { containers.touchApp(containerId, app.id) }

    fun openUninstaller(containerId: String) = launch(containerId, "uninstaller", listOf("uninstaller"))
}
