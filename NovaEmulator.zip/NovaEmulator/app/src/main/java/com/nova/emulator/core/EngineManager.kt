package com.nova.emulator.core

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Gestiona paquetes de motor (Wine + Box64 + DXVK...). La app NO incluye binarios: el usuario
 * importa un .zip con un nova-engine.json y los binarios ARM64 que haya obtenido respetando
 * sus licencias. Si no hay motor válido, nada se puede ejecutar.
 */
class EngineManager(context: Context) {
    private val ctx = context.applicationContext
    private val root = File(ctx.filesDir, "engines").apply { mkdirs() }
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    private val _engines = MutableStateFlow<List<Engine>>(emptyList())
    val engines: StateFlow<List<Engine>> = _engines

    init { refresh() }

    fun dirOf(id: String) = File(root, id)

    fun find(id: String?): Engine? = _engines.value.firstOrNull { it.id == id }

    fun refresh() {
        _engines.value = root.listFiles { f -> f.isDirectory && !f.name.startsWith(".") }
            .orEmpty().mapNotNull(::load).sortedBy { it.manifest.name }
    }

    private fun load(dir: File): Engine? {
        val mf = File(dir, "nova-engine.json")
        if (!mf.isFile) return null
        val m = runCatching { json.decodeFromString<EngineManifest>(mf.readText()) }.getOrNull() ?: return null
        return Engine(dir.name, m, check(dir, m))
    }

    private fun check(dir: File, m: EngineManifest): String? {
        val box = File(dir, m.box64Path)
        val wine = File(dir, m.winePath)
        return when {
            !box.isFile -> "Falta ${m.box64Path}"
            !wine.isFile -> "Falta ${m.winePath}"
            !box.canExecute() -> "${m.box64Path} no es ejecutable"
            else -> null
        }
    }

    suspend fun importZip(uri: Uri): Result<Engine> = withContext(Dispatchers.IO) {
        runCatching {
            val tmp = File(root, ".tmp-${System.nanoTime()}").apply { mkdirs() }
            try {
                val input = ctx.contentResolver.openInputStream(uri) ?: error("No se pudo abrir el archivo")
                input.use { unzip(it, tmp) }
                val mf = File(tmp, "nova-engine.json")
                require(mf.isFile) { "El paquete no contiene nova-engine.json" }
                val m = json.decodeFromString<EngineManifest>(mf.readText())
                require(m.arch == "arm64-v8a") { "Arquitectura no soportada: ${m.arch} (se requiere arm64-v8a)" }
                val id = "${m.name}-${m.version}".replace(Regex("[^A-Za-z0-9._-]"), "_")
                val dest = File(root, id)
                if (dest.exists()) dest.deleteRecursively()
                require(tmp.renameTo(dest)) { "No se pudo instalar el motor" }
                markExecutables(dest, m)
                refresh()
                find(id) ?: error("Motor instalado pero no legible")
            } catch (e: Throwable) {
                tmp.deleteRecursively()
                throw e
            }
        }
    }

    fun delete(id: String) {
        dirOf(id).deleteRecursively()
        refresh()
    }

    // ZipInputStream no conserva permisos Unix: se reasignan a binarios conocidos.
    private fun markExecutables(dir: File, m: EngineManifest) {
        dir.walkTopDown().filter { it.isFile && (it.parentFile?.name == "bin" || it.extension == "so") }
            .forEach { it.setExecutable(true) }
        listOf(m.box64Path, m.winePath).forEach { File(dir, it).setExecutable(true) }
    }

    private fun unzip(input: InputStream, dest: File) {
        val base = dest.canonicalPath + File.separator
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val out = File(dest, e.name)
                // Protección zip-slip
                require(out.canonicalPath.startsWith(base)) { "Entrada de ZIP no válida: ${e.name}" }
                if (e.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zip.copyTo(it) }
                }
            }
        }
    }
}
