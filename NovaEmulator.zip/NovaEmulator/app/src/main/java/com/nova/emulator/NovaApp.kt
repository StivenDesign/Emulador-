package com.nova.emulator

import android.app.Application
import com.nova.emulator.core.ContainerManager
import com.nova.emulator.core.EngineManager
import com.nova.emulator.core.ProcessRunner

class NovaApp : Application() {
    lateinit var engines: EngineManager
    lateinit var containers: ContainerManager
    lateinit var runner: ProcessRunner

    override fun onCreate() {
        super.onCreate()
        engines = EngineManager(this)
        containers = ContainerManager(this)
        runner = ProcessRunner(this, engines, containers)
    }
}
