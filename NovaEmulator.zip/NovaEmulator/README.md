# NOVA EMULATOR

App Android (Kotlin + Jetpack Compose) para gestionar entornos de Wine y ejecutar programas de
Windows mediante un motor (Wine + Box64 + DXVK...) que el usuario importa. Estado: **v0.1, Fases 1–4
y parte de la 6**. Lee `docs/01-VIABILIDAD.md` antes de nada.

## Qué funciona realmente (en el código)

- Importar paquetes de motor `.zip` con validación, protección zip-slip y comprobación de binarios.
- Crear/editar/eliminar entornos con prefijo de Wine propio y `config.json` persistente.
- Importar `.exe`/`.msi` con el selector del sistema (sin permisos de almacenamiento), con aviso de
  seguridad y confirmación antes de ejecutar. Nunca se ejecuta nada automáticamente.
- Lanzar procesos reales (`box64 wine ...`): inicializar prefijo (`wineboot`), instalar EXE/MSI
  (`msiexec /i`), ejecutar, detener y abrir el desinstalador de Wine.
- Registro con la salida real del proceso y los errores del sistema, sin ocultarlos.
- Buscar `.exe` dentro del prefijo y registrarlos como aplicación o juego.

## Qué NO existe todavía

| Elemento | Estado |
|---|---|
| Binarios de Wine/Box64/DXVK/Turnip | No incluidos: se importan (ver formato abajo) |
| Servidor X11 y salida de ventana/pantalla | Pendiente (Fases 5 y 7). Sin él, los programas con interfaz no mostrarán ventana |
| Resolución y wrapper gráfico | Se guardan, pero aún no se aplican |
| Límite de memoria | Solo informativo; Android no permite limitarlo a una app |
| FPS, controles táctiles, mandos Bluetooth, perfiles de rendimiento | Pendiente (Fase 7); no hay botones falsos |
| Administrador de archivos | Pendiente |
| JNI/NDK | Aún sin código nativo; llegará con el servidor gráfico |
| Compatibilidad probada con apps reales | Ninguna (no se ha podido probar en dispositivo) |

El código **no se ha compilado ni ejecutado**: el entorno donde se creó no tiene Android SDK ni red.
Pueden aparecer errores de compilación al abrirlo por primera vez.

## Compilar

Requisitos: Android Studio Ladybug o superior (o JDK 17 + Android SDK 35), conexión a internet.

```bash
cd NovaEmulator
# Abre la carpeta en Android Studio, o desde terminal (necesitas el wrapper):
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Instalación: copia la APK al móvil (ARM64, Android 8+) y permite "instalar apps desconocidas".

## Formato del paquete de motor

Un `.zip` con `nova-engine.json` en la raíz y los binarios ARM64 que hayas obtenido cumpliendo sus licencias:

```json
{
  "name": "mi-motor",
  "version": "1.0",
  "wineVersion": "9.x",
  "box64Path": "bin/box64",
  "winePath": "wine/bin/wine64",
  "libraryPaths": ["lib", "wine/lib"],
  "dxvkVersion": "2.x",
  "arch": "arm64-v8a"
}
```

## Decisión de seguridad/arquitectura: targetSdk 28

Desde Android 10 (targetSdk 29+) no se pueden ejecutar binarios del almacenamiento de la app. Por eso
`targetSdk = 28`. Implica distribución por APK directo, no Google Play, y Android puede mostrar
avisos de compatibilidad.

## Licencias

Wine (LGPL), Box64/Box86 (MIT), DXVK (zlib), VKD3D-Proton (LGPL), Mesa/Turnip (MIT), FEX-Emu (MIT).
Confirma cada licencia en el repositorio de la versión que uses. Esta app no redistribuye ninguno.

## Estructura

```
NovaEmulator/
├── docs/01-VIABILIDAD.md
├── settings.gradle.kts · build.gradle.kts · gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/nova/emulator/
            ├── NovaApp.kt · MainActivity.kt
            ├── core/   Models · EngineManager · ContainerManager · ProcessRunner
            └── ui/     Theme · NovaViewModel · Screens
```

## Siguientes fases

5. Integrar un servidor X11 (partiendo del enfoque abierto de Winlator) y salida gráfica con Vulkan.
6. Dependencias por entorno (vcrun, .NET, DirectX redistributable).
7. Modo gaming: FPS reales, controles táctiles, mandos, perfiles.
8–10. Pruebas en dispositivos, optimización y APK firmada.
