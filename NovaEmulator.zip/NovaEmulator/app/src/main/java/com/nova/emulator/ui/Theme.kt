package com.nova.emulator.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val NovaBg = Color(0xFF0A0B14)
val NovaPurple = Color(0xFF8B5CF6)
val NovaCyan = Color(0xFF22D3EE)
val NovaOk = Color(0xFF34D399)
val NovaWarn = Color(0xFFFBBF24)
val NovaErr = Color(0xFFF87171)

private val scheme = darkColorScheme(
    primary = NovaPurple, secondary = NovaCyan, background = NovaBg, surface = Color(0xFF12141F),
    onBackground = Color(0xFFE5E7EB), onSurface = Color(0xFFE5E7EB), error = NovaErr,
)

@Composable
fun NovaTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = scheme, content = content)

val novaGradient = Brush.linearGradient(listOf(NovaPurple, NovaCyan))

/** Tarjeta "glass": superficie translúcida con borde claro y degradado sutil. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.06f),
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.22f), Color.White.copy(0.04f)))),
    ) {
        Box(Modifier.background(Brush.linearGradient(listOf(NovaPurple.copy(0.10f), Color.Transparent))).padding(16.dp)) { content() }
    }
}

@Composable
fun Modifier.clipCard() = this.clip(RoundedCornerShape(20.dp))
