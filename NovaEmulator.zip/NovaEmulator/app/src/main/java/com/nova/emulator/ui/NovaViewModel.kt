package com.nova.emulator.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.emulator.NovaApp
import com.nova.emulator.core.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class NovaViewModel(app: Application) : AndroidViewModel(app) {
    private val nova = app as NovaApp

    val engines = nova.engines.engines
    val containers = nova.containers.containers
    val running = nova.runner.running
    val logs = nova.runner.logs

    val selectedId = MutableStateFlow<String?>(null)
    val pendingInstall = MutableStateFlow<PendingInstall?>(null)
    val scanResults = MutableStateFlow<List<File>>(emptyList())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private fun say(s: String) { messages.tryEmit(s) }

    fun selectedContainer(list: List<ContainerConfig>) = list.firstOrNull { it.id == selectedId.value } ?: list.firstOrNull()

    fun importEngine(uri: Uri) = viewModelScope.launch {
        nova.engines.importZip(uri)
            .onSuccess { say("Motor importado: ${it.manifest.name} ${it.manifest.version}" + (it.problem?.let { p -> " (aviso: $p)" } ?: "")) }
            .onFailure { say("No se pudo importar el motor: ${it.message}") }
    }

    fun deleteEngine(id: String) = nova.engines.delete(id)

    fun createContainer(name: String, engineId: String?) {
        if (name.isBlank()) return say("Escribe un nombre")
        selectedId.value = nova.containers.create(name, engineId).id
    }

    fun updateContainer(id: String, f: (ContainerConfig) -> ContainerConfig) = nova.containers.update(id, f)
    fun deleteContainer(id: String) { nova.containers.delete(id); if (selectedId.value == id) selectedId.value = null }

    fun initPrefix(id: String) = report(nova.runner.initPrefix(id))

    /** Copia el instalador y pide confirmación; no se ejecuta nada automáticamente. */
    fun importInstaller(containerId: String, uri: Uri) = viewModelScope.launch {
        nova.containers.importInstaller(containerId, uri)
            .onSuccess {
                val name = it.name.lowercase()
                if (!name.endsWith(".exe") && !name.endsWith(".msi")) say("Archivo copiado, pero no es .exe ni .msi: ${it.name}")
                else pendingInstall.value = PendingInstall(containerId, it.path, name.endsWith(".msi"))
            }
            .onFailure { say("No se pudo importar: ${it.message}") }
    }

    fun confirmInstall() {
        val p = pendingInstall.value ?: return
        pendingInstall.value = null
        report(nova.runner.runInstaller(p))
    }

    fun cancelInstall() { pendingInstall.value = null }

    fun scan(containerId: String) = viewModelScope.launch {
        scanResults.value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            nova.containers.scanExecutables(containerId)
        }
        if (scanResults.value.isEmpty()) say("No se encontraron ejecutables en el prefijo")
    }

    fun register(containerId: String, exe: File, isGame: Boolean) {
        nova.containers.addApp(containerId, InstalledApp(UUID.randomUUID().toString().take(8), exe.nameWithoutExtension, exe.path, isGame))
        scanResults.value = scanResults.value - exe
    }

    fun removeApp(containerId: String, appId: String) = nova.containers.removeApp(containerId, appId)
    fun runApp(containerId: String, app: InstalledApp) = report(nova.runner.runApp(containerId, app))
    fun openUninstaller(containerId: String) = report(nova.runner.openUninstaller(containerId))
    fun stop(sessionId: String) = nova.runner.stop(sessionId)
    fun clearLogs() = nova.runner.clearLogs()

    private fun report(r: Result<String>) = r.onFailure { say("No se pudo ejecutar: ${it.message}") }
}
