package com.nova.emulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.nova.emulator.ui.NovaRoot
import com.nova.emulator.ui.NovaTheme
import com.nova.emulator.ui.NovaViewModel

class MainActivity : ComponentActivity() {
    private val vm: NovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaTheme { NovaRoot(vm) } }
    }
}
